import { Router } from 'express';
import upload from '../middlewares/upload';

const router = Router();

router.get('', (req, res) => {
    res.send('api works');
})

router.post('/upload', upload.single('file'), (req, res) => {
    console.log('File: ', req.file);
    if (req.file) {
        res.send('File sent succesfully');
    } else {
        res.sendStatus(400).send('File not supported')
    }
})

router.post('/uploads', upload.array('files'), (req, res) => {
    console.log('File: ', req.file);
    if (req.files && req.files.length) {
        res.send('Files sent succesfully');
    } else {
        res.sendStatus(400).send('File not supported')
    }
})

export default router;